def function2(x):
    # return sum of digits of integer of number
    x = int(x)
    l = []
    while len(list(str(x))) != 1:
        s = x % 10
        l.append (s)
        x = x // 10
    l.append(x)
    su = sum(l)
    return su

def testing(n):
    a = "input"
    b = "output"
    ttt = True
    for i in range(n):
        t = a + str(i + 1) + ".txt"
        with open(t, "r") as ank:
            inp = float(ank.read())
        real = function2(inp)
        t = b + str(i + 1) + ".txt"
        with open(t, "r") as ank:
            out = int(ank.read())
        if real == out:
            pass
        else:
            ttt = False
            break
    return ttt

from A2_2021232_B1_cases import * 

n = generateData()
ans = (testing(n))
if ans:
    print("SUCCESS")
else:
    print ("FAIL")