def function1(x):
    # return sum of digits of  integer value x
    l = sum(list(map(int ,list(str(int(x))))))
    return l

def generateData():
    # take list of n inputs
    l = [float(x) for x in input("Give list of numbers (spce-seprated) to be processed ").split()]
    a = "input"
    b = "output"
    c = 1
    for i in l:
        t = a + str(c) + ".txt"
        with open(t, "w") as ank:
            ank.write(str(i))
        tt = function1(i)
        t = b + str(c) + ".txt"
        with open(t, "w") as ank:
            ank.write(str(tt))
        c = c + 1
    print(f"n for testing is {len(l)}")
    return len(l)