def transpose(t):
    len_t = len(t)   # 5
    len_i = len(t[0])  # 6
    ans = []
    i = 0
    for i in range(len_i):
        p = []
        for j in range(len_t):
            p.append(t[j][i])
        ans.append(p)
    return ans

def awards(t,p,q):
    pp = True
    for i in t:
        if i[-1] != 1:
            pp = False
            break
        else:
            for j in range(len(i)):
                if i[j] == 1:
                    c = j
                    gupta = i[c:]
                    for k in gupta:
                        if k == 0:
                            pp = False
                            break
                    if pp == False:
                        break
    if pp:
        c = len(t)
        '''
        [0,0,0,0,1,1] -- 0
        [0,0,0,1,1,0] -- 1
        [0,1,1,1,1,1] -- 2
        [0,0,1,0,1,1] -- 3 
        [0,0,1,1,1,1] -- 4
        '''
        total = []
        for i in t:
            s = sum(i)
            total.append(s)
        # total = [2,3,5,4,4]
        l = len(total)
        dog = []
        snake = []
        for i in range(l): # 5
            a = max(total)
            b = total.index(a)
            if i % 2 == 0:
                # dog
                j_1 = []
                for j in t[b]:
                    if j == 0:
                        j_1.append("0")
                    else:
                        j_1.append("D")
                t[b] = j_1
                s = p*a
                dog.append(s)
            else:
                # snake
                j_1 = []
                for j in t[b]:
                    if j == 0:
                        j_1.append("0")
                    else:
                        j_1.append("S")
                t[b] = j_1
                d = q*a
                snake.append(d)
            total[b] = -1
            p = p + 1
            q = q + 1
        ankush = transpose(t)
        ans = [ankush,sum(dog),sum(snake)]
        return ans
    else:
        return [pp]

x = [int(x) for x in input("Give inital number of grammy ").split()]
p , q = x[0] , x[1]
x = [int(x) for x in input("Information obout sky scrapers ").split()]
m , n = x[0] , x[1]
t = []
for i in range(m):
    t_i = [int(x) for x in input("Give information about floor ").split()]
    if len(t_i) == n:
        tt = True
        t.append(t_i)
    else:
        False
        break
ankush = transpose(t)
ank = awards(ankush,p,q)
if len(ank) == 1:
    print("Wrong input in case of buildings.")
else:
    print(ank[1],ank[2])
    for i in ank[0]:
        print(*i)