import math
def scaling(sx,sy,sz,x,y,z):
    x_s = []
    for i in x:
        n = sx*i
        x_s.append(n)
    y_s = []
    for i in y:
        n = sy*i
        y_s.append(n)
    z_s = []
    for i in z:
        n = sz*i
        z_s.append(n)
    return [x_s , y_s , z_s]
def translating(tx,ty,tz,x,y,z):
    x_t = []
    y_t = []
    z_t = []
    for i in x:
        n = 1*i + tx
        x_t.append(n)
    for i in y:
        n = 1*i + ty
        y_t.append(n)
    for i in z:
        n = 1*i + tz
        z_t.append(n)
    return [x_t , y_t , z_t]
def rotation(axis,angle,x,y,z,len_l):
    x_r = []
    y_r = []
    z_r = []
    sin = math.sin(math.radians(angle))
    cos = math.cos(math.radians(angle))
    if axis == 'x':
        for i in range(0,len_l):
            xx = 1*x[i]
            x_r.append(xx)
            yy = cos*y[i] - sin*z[i]
            y_r.append(yy)
            zz = sin*y[i] + cos*z[i]
            z_r.append(zz)
    elif axis == 'y':
        for i in range(0,len_l):
            xx = cos*x[i] + sin*z[i]
            x_r.append(xx)
            yy = 1*y[i]
            y_r.append(yy)
            zz = -sin*x[i] + cos*z[i]
            z_r.append(zz)
    else:           # axis = 'z' 
        for i in range(0,len_l):
            xx = cos*x[i] - sin*y[i]
            x_r.append(xx)
            yy = cos*y[i] + sin*x[i]
            y_r.append(yy)
            zz = 1*z[i]
            z_r.append(zz)
    return [x_r,y_r,z_r]
n = int(input("Give no of vertices of 3-D shape: "))
x = [float(i) for i in input("Give x of vertices space-seprated: ").split()]
y = [float(i) for i in input("Give y of vertices space-seprated: ").split()]
z = [float(i) for i in input("Give z of vertices space-seprated: ").split()]
print("-------------------------------------------------------------------")
print("")
print("Menu for transformations")
print("")
print("S:  Scaling ,requirements-Sx,Sy,Sz (where Sx,Sy,Sz are numbers for scaling) ")
print("T:  Translating ,requirements-Tx,Ty,Tz (where Tx,Ty,Tz are numbers for translating) ")
print("R:  Rotating ,requirements-x,fi (where x is axis and fi is angle(in degree and in between 0 to 360) for rotating) ")
print("")
print("-------------------------------------------------------------------")
tt = True
if (len(x) == n) and (len(y) == n) and (len(z) == n):
    pass
else:
    tt = False
    print("Wrong input for vetrices")
if tt:
    with open("ques2.txt" , "w") as ankush:
        ankush.write("Initial condition of matrix:" + "\n")
        ankush.write(f"x vertices of: {x}" + "\n")
        ankush.write(f"y vertices of: {y}" + "\n")
        ankush.write(f"z vertices of: {z}" + "\n")
    q = int(input("The number of transformation queries to apply: "))
    q_r = []
    for i in range(0,q):
        q_r_1 = [i for i in input("Give code and requirements of transformation space seprated").split()]
        q_r.append(q_r_1)
    udit = 1
    for i in q_r:
        if i[0] == "S":
            if len(i) == 4:
                sx = float(i[1])
                sy = float(i[2])
                sz = float(i[3])
                ans = scaling(sx,sy,sz,x,y,z)
            else:
                print("Wrong input for query")
                tt = not tt
        elif i[0] == "T":
            if len(i) == 4:
                tx = float(i[1])
                ty = float(i[2])
                tz = float(i[3])
                ans = translating(tx,ty,tz,x,y,z)
            else:
                print("Wrong input for query")
                tt = not tt
        elif i[0] == "R":
            if len(i) == 3:
                fi = i[2]
                if i[1] in ["x" , "y" , "z"]:
                    if (float(fi)>= 0) and (float(fi)<= 360):
                        len_l = len(x)
                        ans = rotation(i[1],float(i[2]),x,y,z,len_l)
                    else:
                        tt = not tt
                        print("Wrong input angle")
                else:
                    tt = not tt
                    print("Wrong input axis")
            else:
                print("Wrong input for query")
                tt = not tt
        else:
            print("Wrong input for query's code")
            tt = not tt
        if tt:
            x = ans[0]
            y = ans[1]
            z = ans[2]
            with open("ques2.txt" , "a") as ankush:
                ankush.write(f"Matrix after {udit}th query is :" + "\n")
                ankush.write(str(x) + "\n")
                ankush.write(str(y) + "\n")
                ankush.write(str(z) + "\n")
        else:
            with open("ques2.txt" , "a") as ankush:
                ankush.write(f"There is a problem in {udit}th query")
        udit = udit +1
    print("Final matrix after all possible transformation is:")
    print(f"[ {x}")
    print(y)
    print(f"{z} ]")
    with open("ques2.txt" , "a") as ankush:
                ankush.write(f"Matrix after all possible queries query is :" + "\n")
                ankush.write(str(x) + "\n")
                ankush.write(str(y) + "\n")
                ankush.write(str(z) + "\n")
# angle = 90
# axis = "x"
# x = [0,0,0,0,4,4,4,4]
# y = [0,0,3,3,3,0,0,3]
# z = [0,2,2,0,0,0,2,2]
# len_l = len(x)
# print(rotation(axis,angle,x,y,z,len_l))