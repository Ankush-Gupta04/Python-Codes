# m = [{1234}
#      {5678}
#      {9101112}
#      {13141516}]
def normal(m):
    ans = []
    for i in m:
        ans.extend(i)
    return ans

def alternate(m):
    i = 0
    ans = []
    for k in m:
        if i%2 == 0:
            pass
        else:
            k.reverse()
        ans.extend(k)
        i = i+1
    return ans

def spiral(m):
    ans = []
    i = 0
    l = len(m)
    while l != 0:
        if i % 4 == 0:
            ank = m.pop(0)
        elif i % 4 == 1:
            ank = []
            for k in m:
                ank.append(k[-1])
                k.pop(-1)
        elif i % 4 == 2:
            ank = []
            ank = m.pop(-1)
            ank.reverse()
        else:
            ank = []
            for k in m:
                ank.append(k[0])
                k.pop(0)
            ank.reverse()
        ans.extend(ank)
        i = i+1
        l = len(m)
    return ans
        
def bound(m):
    l = m[0]
    n = m[-1]
    n.reverse()
    t = []
    r = []
    for i in m[1:-1]:
        t.append(i[-1])
        r.append(i[0])
    ans = l
    ans.extend(t)
    ans.extend(n)
    r.reverse()
    ans.extend(r)
    return ans
def diag_r(m):
    l = len(m)
    ans = []
    s = 3 + 2*(l-2)
    s = int(s/2) + 1
    for i in range(s):
        t = i
        l_1 = []
        for j in range(0,i+1):
            ankush = m[j][t-j]
            l_1.append(ankush)
        ans.extend(l_1)
    ans_1 = []
    for i in range(s-1):
        t = l-i -1
        l_1 = []
        for j in range(l-1,l-2-i,-1):
            ankush = m[j][t-j+l-1]
            l_1.append(ankush)
        ans_1.extend(l_1)
    ans_1.reverse()
    ans.extend(ans_1)
    return ans
def diag_l(m):
    l = len(m)
    ans = []
    s = 3 + 2*(l-2)
    s = int(s/2) + 1
    ans_1 = []
    for i in range(s):
        t = l-1-i
        l_1 = []
        for j in range(0,i+1):
            ankush = m[j][t+j]
            l_1.append(ankush)
        ans_1.extend(l_1)
    ans.extend(ans_1)
    ans_1 = []
    for i in range(s-1):
        t = i
        l_1 = []
        for j in range(l-1,l-2-i,-1):
            ankush = m[j][t+j-l+1]
            l_1.append(ankush)
        ans_1.extend(l_1)
    ans_1.reverse()
    ans.extend(ans_1)
    return ans
m = []
n = int(input("Give size of matrix: "))
for i in range(n):
    m_i = [float(x) for x in input(f"Give {i+1}th row: ").split()]
    m.append(m_i)
tt = True
for i in m:
    a = len(i)
    if a != n:
        print ("Wrong input")
        tt = False
        break
    else:
        pass
if tt:
    print ("Menu")
    print ("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------")
    print ("1) Normal traversal:  from left to right for each row.")
    print ("2) Alternating traversal:  first left to right for the first row, then right to left for the second row,then left to right for the third row, and so on.")
    print ("3) Spiral traversal: from outer to inwards.")
    print ("4) Boundary traversal: First, traverse the upper boundary from left to right, then rightboundary from up to down, then bottom boundary from right to left and at last from left boundary from down to up.")
    print ("5) Diagonal traversal: from right to left.")
    print ("6) Diagonal traversal: from left to right.")
    print ("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------")
    menu = int(input("Give code of process: "))
    if (menu <= 0) or (menu >7):
        print("Wrong input")
        tt = False
    elif menu == 1:
        ans = normal(m)
    elif menu == 2:
        ans = alternate(m)
    elif menu == 3:
        ans = spiral(m)
    elif menu == 4:
        ans = bound(m)
    elif menu == 5:
        ans = diag_r(m)
    else:
        ans = diag_l(m)   # menu == 6
if tt:
    str_ans = ""
    for i in ans:
        str_ans = str_ans + str(i) + " "
    print (str_ans)