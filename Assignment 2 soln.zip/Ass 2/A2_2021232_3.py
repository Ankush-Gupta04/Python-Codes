def converter(a,b,l,dicti):
    num = []
    len_l = len(l)
    key = list(dicti.keys())
    value = list(dicti.values())
    ans = []
    if "." in l:
        t = l.index(".")
        for i in range(0,t):
            tt = key[value.index(l[i])]
            n = tt*((a)**(t-i-1))
            num.append(n)
        no = sum(num)
        while no != 0 :
            aa = no % b
            aaa =  value[key.index(aa)]
            ans.append(aaa)
            no = no // b
        ans.reverse()
        ans.append(".")
        num.clear()
        for i in range(t+1 , len_l):
            tt = key[value.index(l[i])] 
            n = tt*(a**(t-i))
            num.append(n)
        no = sum(num)
        for i in range(0,15):
            no = no*b
            ankush = int(no)
            ans.append(value[key.index(ankush)])
            no = no -ankush                    
    else:
        for i in range(0,len_l):
            tt = key[value.index(l[i])] 
            n = tt*((a)**(len_l-i-1))
            num.append(n)
        no = sum(num)
        ans = []
        while no != 0 :
            aa = no % b
            aaa =  value[key.index(aa)]
            ans.append(aaa)
            no = no // b
        ans.reverse()
    stri = ""
    for i in ans:
        stri = stri + i
    print(stri, " (approx.)")

print("Menu")
print("----------------------------------------------------------------------------------------------------")
print("")
print("1: Convert decimal to binary and vice-versa")
print("2: Convert decimal to hexadecimal and vice-versa")
print("3: Convert decimal to octal and vice-versa.")
print("4: Convert binary to hexadecimal and vice-versa.")
print("5: Convert binary to octal and vice-versa.")
print("6: Convert hexadecimal to octal and vice-versa")
print("7: Convert number with radix A to radix B. Here A,B <= 36. In this case, you must take A,B as input.")
print("")
print("----------------------------------------------------------------------------------------------------")
n = int(input("Give code from above menu for the process that you want to perform: "))
dicti = {0 : '0' ,1 : '1' ,2 : '2' , 3 : '3' , 4 : '4' , 5 : '5' , 6 : '6' , 7 : '7' , 8 : '8' , 9 : '9' , 10 : 'A', 11 : 'B' , 12 : 'C' , 13 : 'D' , 14 : 'E' , 15 : 'F' , 16 : 'G' , 17 : 'H' , 18 : 'I' , 19 : 'J' , 20 : 'K' , 21 : 'L' , 22 : 'M', 23 : 'N' , 24 : 'O' , 25 : 'P' , 26 : 'Q' , 27 : 'R' , 28 : 'S' , 29 : 'T' , 30 : 'U' , 31 : 'V' , 32 : 'W' , 33 : 'X' , 34 : 'Y' , 35 :'Z' }
z1 = list(dicti.values())
#print(z1)
tt = True
if (n<0) or (n>7):
    print("You gave wrong input for your code")
    tt = False
else:
    print(f"You have chosen code:- {n}")
    z = input("Give your number that need to be converted ")
    l = [x for x in z]
    if n == 1:
        x = int(input("Give initial radix of number system "))
        if x == 2:
            a = 2
            b = 10
        elif x == 10:
            a = 10
            b = 2
        else:
            print("wrong input of radix")
            tt = False
    elif n == 2:
        x = int(input("Give initial radix of number system "))
        if x == 16:
            a = 16
            b = 10
        elif x == 10:
            a = 10
            b = 16
        else:
            print("wrong input of radix")
            tt = False
    elif n == 3:
        x = int(input("Give initial radix of number system "))
        if x == 8:
            a = 8
            b = 10
        elif x == 10:
            a = 10
            b = 8
        else:
            print("wrong input of radix")
            tt = False
    elif n == 4:
        x = int(input("Give initial radix of number system "))
        if x == 2:
            a = 2
            b = 16
        elif x == 16:
            a = 16
            b = 2
        else:
            print("wrong input of radix")
            tt = False
    elif n == 5:
        x = int(input("Give initial radix of number system "))
        if x == 2:
            a = 2
            b = 8
        elif x == 8:
            a = 8
            b = 2
        else:
            print("wrong input of radix")
            tt = False
    elif n == 6:
        x = int(input("Give initial radix of number system "))
        if x == 16:
            a = 16
            b = 8
        elif x == 8:
            a = 8
            b = 16
        else:
            print("wrong input of radix")
            tt = False
    else:                       # n = 7
        a = int(input("Give initial radix of number system "))
        b = int(input("Give final radix of number system "))
        if a and b not in range(2,37):
            tt = False
if tt:
    #print(l)
    for i in l:
        if i != ".":
            if i not in z1[0:a]:
                print("Wrong input for number")
                tt = False
                break
            else:
                pass
        else:
            pass
#print(tt)
if tt:
    converter(a,b,l,dicti)