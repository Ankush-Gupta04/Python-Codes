def series(a,t):
    l = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B", "C'", "C#'", "D'", "D#'", "E'", "F'", "F#'", "G'", "G#'", "A'", "A#'", "B'"]
    ans = []
    # Root W W H W W W H
    # 1    2 3 4 5 6 7 8
    n = 8
    if a in l:
        if t == "m":
            i = 2
            ans.append(a) # c i = 1
            while i != n+1 :
                p = l.index(a)
                if i % 4 == 0:
                    p = p+1
                else: 
                    p = p+2
                a = l[p]
                ans.append(a)
                i = i+1
        else:
            # Root W H W W H W W
            # 1    2 3 4 5 6 7 8
            i = 2
            ans.append(a) # c i = 1
            while i != n+1 :
                p = l.index(a)
                if i % 3 == 0:
                    p = p+1
                else: 
                    p = p+2
                a = l[p]
                ans.append(a)
                i = i+1
        str_ans = ""
        for i in ans:
            str_ans = str_ans + i + " "
        return str_ans
    else:
        print("Wrong input for a")
        return
                
def noteCreate():
    l = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"]
    with open("scaleMajor.txt" , "w") as major:
        for i in l:
            major.write(series(i,"m")+ "\n")
    with open("scaleMinor.txt" , "w") as major:
        for i in l:
            major.write(series(i,"M")+ "\n")

def majorNotes(root):
    l = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"]
    with open("scaleMajor.txt" , "r") as major:
        a = l.index(root)
        r = major.read()
        l_1 = [x for x in r.split("\n")]
        return (l_1[a])
def minorNotes(root):
    l = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"]
    a = l.index(root)
    with open("scaleMinor.txt" , "r") as major:
        r = major.read()
        l_1 = [x for x in r.split("\n")]
        return (l_1[a])
root = input("Enter the root note: ")
type_i = input("Enter the type of scale(Major/Minor): ")
noteCreate()
if type_i == "Major":
    print(f"The {type_i} of {root} is:")
    print(majorNotes(root))
elif type_i == "Minor":
    print(f"The {type_i} of {root} is:")
    print(minorNotes(root))
else:
    print("wrong input")