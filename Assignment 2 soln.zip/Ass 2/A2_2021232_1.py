def all(t):
    l = [a for a in t.split()]   # create a list of all words 
    l = list(set(l))              # use set to remove repeat and then create list to give a word a specific no
    s = ""                            
    for i in l[0:-1]:
        s = s+ i + " ; "
    s = s + l[-1]
    return(s)

def allcount(t):
    l = all(t)                                     # call previous fn to get all unique word
    n = [x for x in l.split(" ; ")]                  # convert string to list
    abc = [a for a in t.split()]
    tt  = {}
    for i in n:
        count_i = abc.count(i)
        tt[i] = count_i
    return tt

def specificcount(x,t):
    tt = allcount(t)              # call previous fn for ease
    return tt.get(x , "Word doesnot exist")

def replace(x,y,t):
    tt = t.replace(x,y)
    with open("question1_input.txt" , "w") as rep:
        rep.write(tt)
    return

while 4 != 0 :    # creating an infinite loop
    with open("question1_input.txt" , "r") as q1:
        t = q1.read()
        print("------------------------------------------------------------------")
        print("Menu")
        print("1. Display specific word count")
        print("2. Display all Unique Words")
        print("3. Display all word Counts")
        print("4. Replace word")
        print("5. Quit")
        print("------------------------------------------------------------------")
        n = int(input("Give code for your desired process: "))
        print(f"You have chosen code: {n}")
        if (n>5) or (n<1):
            ans = ("You have chosen wrong code. Try again!!")
        elif n == 5:
            print("You choose to leave application.")
            break
        elif n == 1:
            print("I will display specific word count")
            x = input("Enter Word: ")
            ans = specificcount(x,t)
        elif n == 2:
            print("I will display all unique words")
            ans = all(t)
        elif n == 3:
            print ("I will display all words count")
            ans = allcount(t)
        else:
            x = input("Give word that need to be replaced: ")
            y = input(f"Give word that replace {x}: ")
            replace(x,y,t)
            ans = "Task done check original txt file."
        print (ans)
        # giving q1 input to avoid repeative reading also reading is in loop to adjust with last round