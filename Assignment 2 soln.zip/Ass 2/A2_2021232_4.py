# i have brought all files to out of pdf for general use I know i can use addess in place of name but address would be different for evaluator than my laptop's. 
with open("RegisteredStudents.txt" , "r" ) as rs:
    rs_r = rs.read()
    t = [x for x in rs_r.split("\n")]
    l = []
    for i in t:
        b = [x for x in i.split()]
        a = b[0]+"_"+b[1]+".txt"
        l.append(a)
#print(l)
with open("AnswerKey.txt" , "r" ) as a:
    ans = []
    a_r = a.readlines()
    for i in a_r:
        t = [x for x in i.split()]
        ans.append(t[1])
#print(ans)
len_ans = len(ans)
marks = {}
for i in l:
    with open(i , "r" ) as test:
        resp = test.readlines()
        res = []
        for j in  resp:
            res_1 = [x for x in j.split()]
            res.append(res_1[1])
    marks_ind = []
    for k in range(0,len_ans,1):
        if res[k] == "-" :
            marks_ind.append(0)
        elif res[k] == ans[k]:
            marks_ind.append(4)
        else:
            marks_ind.append(-1)
        marks[i] = sum(marks_ind)
#print(marks)
for i in marks:
    name = marks.keys()
#print(name)
final = []
for i in name:
    c = marks[i]
    ankush = i[0:-4]
    ank = [x for x in ankush.split("_")]
    ankush = ank[0] + " " + ank[1] + " " + str(c)
    #print(ankush)
    final.append(ankush)
with open("FinalReport.txt" , "w" ) as finals:
    for i in final[0:-1]:
        finals.write(i + "\n")
    finals.write(final[-1])
print("Result is created.")