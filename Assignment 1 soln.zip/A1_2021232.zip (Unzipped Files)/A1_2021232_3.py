degree = int(input("Give the degree of the polynomial: "))
if degree > 3:
    print ("The given degree is out of our domain.")
elif degree < 0:
    print ("Polynomials doesnot have negeative degree. (''Input Error'')")
elif degree == 0:
    print ("You have given constant not a polynomial.")
    constant = float(input("Give constant: "))
    n_constant = int(constant)
    if constant >= 0:
        if constant >= (n_constant + 0.5): # constant = 5.6 n_constant = 5
            constant = n_constant + 1         # constant = 6
        else:
            constant = n_constant
    else:
        if constant >= (n_constant - 0.5): # -5.4 > -5.5
            constant =  n_constant
        else:
            constant = n_constant - 1            
    upper = int(input("Give upper bound: ") )
    lower = int(input("Give lower bound: "))
    varry = int(input("Give steps of varry: "))
    if lower > upper:
        print("Check your input as lower bound cannot be greater than upper bound. :(Warning)")
    else:
        if constant >=0:
            for i in range(lower,upper+1,varry):
                for k in range(0,constant):
                    print("*",end="")
                print("")
        else:
            constant = constant * (-1)
            for i in range(lower,upper+1,varry): # printed '/' for negeative rest is same
                print("/",end="")
                for k in range(0,constant):
                    print("*",end="")
                print("")
elif degree == 1:
    l = []
    for i in range(0,degree+1,1):
        x = float(input(f"Give coeff.{i+1}: "))
        l.insert(0,x)
    # l = [a2,a1]
    # eqn = a1*x + a2
    a1 = l.pop()
    a2 = l.pop()
    upper = int(input("Give upper bound: ") )
    lower = int(input("Give lower bound: "))
    varry = int(input("Give steps of varry: "))
    if lower > upper:
        print("Check your input as lower bound cannot be greater than upper bound. :(Warning)")
    else:
        n = []
        for i in range(lower,upper+1,varry):
            new = a1*i + a2
            new_1 = int(new)
            if new >= 0:
                if new >= (new_1 + 0.5): #  5.6  5
                    new = new_1 + 1         #  6
                else:
                    new = new_1
            else:
                if new >= (new_1 - 0.5): # -5.4 > -5.5
                    new =  new_1
                else:
                    new = new_1 - 1 
            n.insert(0,new)
        # n is opposite of desired list
        n.reverse()
        for k in n:
            if k>= 0:
                hastle = k
            else:                 # printed '/' for negeative rest is same
                hastle = (-1)*k
                print("/",end="")
            for pi in range(0,hastle):
                print("*",end="")
            print("")
elif degree == 2:
    l = []
    for i in range(0,degree+1,1):
        x = float(input(f"Give coeff.{i+1}: "))
        l.insert(0,x)
    # l = [a3,a2,a1]
    # eqn = a1*(x**2) + a2*x + a3
    a1 = l.pop()
    a2 = l.pop()
    a3 = l.pop()
    upper = int(input("Give upper bound: ") )
    lower = int(input("Give lower bound: "))
    varry = int(input("Give steps of varry: "))
    if lower > upper:
        print("Check your input as lower bound cannot be greater than upper bound. :(Warning)")
    else:
        n = []
        for i in range(lower,upper+1,varry):
            new = a1*(i**2) + a2*i + a3
            new_1 = int(new)
            if new >= 0:
                if new >= (new_1 + 0.5): #  5.6  5
                    new = new_1 + 1         #  6
                else:
                    new = new_1
            else:
                if new >= (new_1 - 0.5): # -5.4 > -5.5
                    new =  new_1
                else:
                    new = new_1 - 1
            n.insert(0,new)
        # n is opposite of desired list
        n.reverse()
        for k in n:
            if k>= 0:
                hastle = k
            else:                         # printed '/' for negeative rest is same
                hastle = (-1)*k
                print("/",end="")
            for pi in range(0,hastle):
                print("*",end="")
            print("")
else:
    l = []
    for i in range(0,degree+1,1):
        x = float(input(f"Give coeff.{i+1}: "))
        l.insert(0,x)
    # l = [a4,a3,a2,a1]
    # eqn = a1*(x**3) + a2*(x**2) + a3*x + a4
    a1 = l.pop()
    a2 = l.pop()
    a3 = l.pop()
    a4 = l.pop()
    upper = int(input("Give upper bound: ") )
    lower = int(input("Give lower bound: "))
    varry = int(input("Give steps of varry: "))
    if lower > upper:
        print("Check your input as lower bound cannot be greater than upper bound. :(Warning)")
    else:
        n = []
        for i in range(lower,upper+1,varry):
            new = a1*(i**3) + a2*(i**2) + a3*i + a4
            new_1 = int(new)
            if new >= 0:
                if new >= (new_1 + 0.5): #  5.6  5
                    new = new_1 + 1         #  6
                else:
                    new = new_1
            else:
                if new >= (new_1 - 0.5): # -5.4 > -5.5
                    new =  new_1
                else:
                    new = new_1 - 1
            n.insert(0,new)
        # n is opposite of desired list
        n.reverse()
        for k in n:
            if k>= 0:
                hastle = k
            else:                             # printed '/' for negeative rest is same
                hastle = (-1)*k
                print("/",end="")
            for pi in range(0,hastle):
                print("*",end="")
            print("")