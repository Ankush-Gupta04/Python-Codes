type_1 = "Right-angled triangle"
type_2 = "Isosceles triangle"
type_3 = "Kite"
type_4 = "Half Kite"
type_5 = "X"
print("------------Menu-------------") # created menu
print(type_1)
print(type_2)
print(type_3)
print(type_4)
print(type_5)
print("------------------------------")
type_input = input("Give type of pattern (enter name as in menu): ") # asked by specific name
n = int(input("Give size of pattern: "))   # asked size
# case 1 simple scenerio of triangle
if type_input == type_1 :
    j = 1
    for i in range(1,n+1):
        for i in range(1,j+1):
            print(i,end="")
        print("")
        j = j+1
# case 4 is extension of case 1 so simple. 
elif type_input == type_4:
    j = 1
    for i in range(1,n+1):
        for i in range(1,j+1):
            print(i,end="")
        print("")
        j = j+1
    j = n  
    for i in range(n-1,0,-1):
        for i in range(1,j):
            print(i,end="")
        print("")
        j = j-1
# case 2 consider blank as star than it is simple
elif type_input == type_2:
    if n % 2 == 0:
        r = range(1,(2*n),2)
        l = list(r)
        no = 2*n -1
        for i in l:
            j = no - i
            j = int(j/2)
            for k in range(0,j,1):
                print(" ",end="")
            new = 1
            for p in range(new,i+1,1):
                print(p,end="")
            for k in range(0,j,1):
                print(" ",end="")
            print("")
    else: 
        print("input is odd, so invalid.") # due to condition given in qs as it would distort figure.
# extension of case 2
elif type_input == type_3:
    if n % 2 == 0:
        r = range(1,(2*n),2)
        l = list(r)
        no = 2*n -1
        for i in l:
            j = no - i
            j = int(j/2)
            for k in range(0,j,1):
                print(" ",end="")
            new = 1
            for p in range(new,i+1,1):
                print(p,end="")
            for k in range(0,j,1):
                print(" ",end="")
            print("")
        l.pop()
        l.reverse()
        for i in l:
            j = no - i
            j = int(j/2)
            for k in range(0,j,1):
                print(" ",end="")
            new = 1
            for p in range(new,i+1,1):
                print(p,end="")
            for k in range(0,j,1):
                print(" ",end="")
            print("")
    else: 
        print("input is odd, so invalid.")
# extension of case 2
elif type_input == type_5:
    if n % 2 == 0:
        r = range(2*n-1,0,-2)
        l = list(r)
        no = 2*n-1
        for i in l:
            j = no - i
            j = int(j/2)
            for k in range(0,j,1):
                print(" ",end="")
            new = 1
            for p in range(new,i+1,1):
                print(p,end="")
            for k in range(0,j,1):
                print(" ",end="")
            print("")
        l.pop()
        l.reverse()
        for i in l:
            j = no - i
            j = int(j/2)
            for k in range(0,j,1):
                print(" ",end="")
            new = 1
            for p in range(new,i+1,1):
                print(p,end="")
            for k in range(0,j,1):
                print(" ",end="")
            print("")
    else:
        print("input is odd, so invalid.")
else:
    print("invaild input of pattern style") # added this for typos