n = int(input("Give number of students: ")) 
for i in range(0,n,1): # creating finite loop as we are  allowed to take input for number of students.
    print(f"student number-{i+1}") # to specify nth student
    shape_1 = "2D"
    shape_2 = "3D"
    shape_input = input("Specify the type of geometry (2D or 3D): ") # taking different input for different menu
    print(f"You have chosen {shape_input} geometry")
    print ("Here is menu for your geometry with its code")
    if shape_input == shape_1: # menu for 2D did to prevent mistake by student
        print("------Menu------")
        print("1 : Square")
        print("2 : Rectangle")
        print("3 : Rhombus")
        print("4 : Parallelogram")
        print("5 : Circle")
        print("6 : Exit")
        print("----------------")
        s_1 = "1"
        s_2 = "2"
        s_3 = "3"
        s_4 = "4"
        s_5 = "5"
        s_6 = "6"
        s_input = input("Give code of shape: ") # asked for code to prevent typos and further no expln as i doing as per formula of a figure
        print(f"You have chosen code no. {s_input}")
        if s_input == s_1:
            print("Your shape is Square")
            side = float(input("Enter the lenght of the side of the Square (in cm): "))
            perimeter = 4*(side)
            area = (side)**2
            print(f"The Perimeter of Square is {perimeter} cm")
            print(f"The Area of Square is {area} sq cm")
        elif s_input == s_2:
            print("Your shape is Rectangle")
            length = float(input("Enter the length of the Rectangle (in cm): "))
            breadth = float(input("Enter the breadth of the Rectangle (in cm): "))
            perimeter = 2*(length + breadth)
            area = (length)*(breadth)
            print(f"The Perimeter of Square is {perimeter} cm")
            print(f"The Area of Square is {area} sq cm")
        elif s_input == s_3:
            print("Your shape is Rhombus")
            side = float(input("Enter the lenght of the side of the Rhombus (in cm): "))
            diagonal_1 = float(input("Enter the length of the diagonal-1 of the Rhombus(in cm): "))
            diagonal_2 = float(input("Enter the length of the diagonal-2 of the Rhombus (in cm): "))
            perimeter = 4*(side)
            area = (1/2)*(diagonal_1)*(diagonal_2)
            print(f"The Perimeter of Square is {perimeter} cm")
            print(f"The Area of Square is {area} sq cm")
        elif s_input == s_4:
            print("Your shape is Parallelogram")
            length = float(input("Enter the lenght  of the Parallelogram (in cm): "))
            breadth = float(input("Enter the breadth of the Parallelogram (in cm): "))
            height = float(input("Enter the height of the Parallelogram with base as breadth (in cm): "))
            perimeter = 2*(length + breadth)
            area = (1/2)*(breadth)*(height)
            print(f"The Perimeter of Parallelogram is {perimeter} cm")
            print(f"The Area of Parallelogram is {area} sq cm")
        elif s_input == s_5:
            print("Your shape is Circle")
            radius = float(input("Enter the lenght of the radius of the Circle (in cm): "))
            pi = 3.14
            perimeter = 2*(pi)*(radius)
            area = (pi)*((radius)**2)
            print(f"The Perimeter of the Circle is {perimeter} cm (aprox.)")
            print(f"The Area of the Circle is {area} sq cm (aprox.)")
        elif s_input == s_6:
            print("You chose to exit the application.")
            break
        else:
            print("Warning : You have chosen wrong shape code which is not in menu.") # for typos
    elif shape_input == shape_2: # for 3d and rest is same asd i did in 2d
        print("------Menu------")
        print("1 : Cube")
        print("2 : Cuboid")
        print("3 : Right Circular Cone")
        print("4 : Hemisphere")
        print("5 : Sphere")
        print("6 : Solid Cylinder")
        print("7 : Hollow Cylinder")
        print("8 : Exit")
        print("----------------")
        s_1 = "1"
        s_2 = "2"
        s_3 = "3"
        s_4 = "4"
        s_5 = "5"
        s_6 = "6"
        s_7 = "7"
        s_8 = "8"
        s_input = input("Give code of 3D figure: ")
        print(f"You have chosen code number {s_input}")
        if s_input == s_1:
            print("You figure is Cube")
            side = float(input("Give side of the Cube: "))
            csa = 4*(side)*(side)
            tsa = 6*(side)*(side)
            volume = (side)**3
            print(f"CSA of the Cube is {csa} sq cm.")
            print(f"TSA of the Cube is {tsa} cubic cm.")
            print(f"Volume of the Cube is {volume}")
        elif s_input == s_2:
            print("You figure is Cuboid")
            length = float(input("Give length of the Cuboid: "))
            breadth = float(input("Give breadth of the Cuboid: "))
            height = float(input("Give height of the Cuboid: "))
            tsa = 2*(length*breadth + length*height + height*breadth )
            volume = (length)*(breadth)*(height)
            csa = 2*(length + breadth )*(height)
            print(f"CSA of the Cuboid is {csa} sq cm.")
            print(f"TSA of the Cuboid is {tsa} sq cm.")
            print(f"Volume of the Cuboid is {volume} cubic cm.")
        elif s_input == s_3:
            print("You figure is Right Circular Cone")
            radius = float(input("Give radius of the Right Circular Cone: "))
            s_height = float(input("Give slant height of the Right Circular cone: "))
            height = float(input("Give height of the Right circular cone: "))
            pi = 3.14
            tsa = (pi)*(radius)*(radius + s_height)
            volume = (1/3)*(pi)*(radius)*(radius)*(height)
            csa = (pi)*(radius)*(s_height)
            print(f"CSA of the Right Circular Cone is {csa} sq cm (approx.)")
            print(f"TSA of the Right Circular Cone is {tsa} sq cm (approx.)")
            print(f"Volume of the Right Circular Cone is {volume} cubic cm (approx.)")
        elif s_input == s_4:
            print("You figure is Hemisphere")
            radius = float(input("Give radius of the Hemisphere: "))
            pi = 3.14
            tsa = 3*(pi)*(radius)*(radius)
            volume = (2/3)*(pi)*((radius)**3)
            csa = (2*(pi)*(radius)*(radius))
            print(f"CSA of the Hemisphere is {csa} sq cm (approx.)")
            print(f"TSA of the Hemisphere is {tsa} sq cm (approx.)")
            print(f"Volume of the Hemisphere is {volume} cubic cm (approx.)")
        elif s_input == s_5:
            print("You figure is Sphere")
            radius = float(input("Give radius of the Sphere: "))
            pi = 3.14
            tsa = 4*(pi)*(radius)*(radius)
            volume = (4/3)*(pi)*((radius)**3)
            csa = (4*(pi)*(radius)*(radius))
            print(f"CSA of the Sphere is {csa} sq cm (approx.)")
            print(f"TSA of the Sphere is {tsa} sq cm (approx.)")
            print(f"Volume of the Sphere is {volume} cubic cm (approx.)")
        elif s_input == s_6:
            print("You figure is Solid Cylinder")
            radius = float(input("Give radius of the Solid Cylinder: "))
            height = float(input("Give height of the Solid Cylinder: "))
            pi = 3.14
            tsa = 2*(pi)*(radius)*(radius + height)
            volume = pi*(radius)*(radius)*(height)
            csa = 2*(pi)*(radius)*(height)
            print(f"CSA of the Solid Cylinder is {csa} sq cm (approx.)")
            print(f"TSA of the Solid Cylinder is {tsa} sq cm (approx.)")
            print(f"Volume of the Solid Cylinder is {volume} cubic cm (approx.)")
        elif s_input == s_7:
            print("You figure is Hollow Cylinder")
            radius_1 = float(input("Give inner radius of the Hollow Cylinder: "))
            radius_2 = float(input("Give outer radius of the Hollow Cylinder: "))
            height = float(input("Give height of the Hollow Cylinder: "))
            pi = 3.14
            if radius_1 > radius_2:
                print("Inner radius cannot be greater than outer radius. so, invalid input.")
            elif radius_1 == radius_2:
                print("Given is a solid sphere as both radius are equal.")
                tsa = 2*(pi)*(radius_1)*(radius_1 + height)
                csa = 2*(pi)*(radius_1)*(height )
                volume = pi*(radius_1)*(radius_1)*(height)
                print(f"CSA of the Cylinder is {csa} sq cm (approx.)")
                print(f"TSA of the  Cylinder is {tsa} sq cm (approx.)")
                print(f"Volume of the Cylinder is {volume} cubic cm (approx.)")        
            else:
                tsa = 2*(pi)*(radius_1 + radius_2)*(height + radius_1 - radius_2 )
                volume = pi*((radius_2)**2 - (radius_1)**2)
                csa = 2*(pi)*(radius_1 + radius_2)*(height)
                print(f"CSA of the Hollow Cylinder is {csa} sq cm (approx.)")
                print(f"TSA of the Hollow Cylinder is {tsa} sq cm (approx.)")
                print(f"Volume of the Hollow Cylinder is {volume} cubic cm (approx.)")
        elif s_input == s_8:
            print("You have chosen to exit the application")
            break
        else:
            print("Warning : You have chosen wrong figure code which is not in menu.") # for typos
    else:
        print("Warning : You have chosen wrong geometry in regards of syllabus.") # for typos 