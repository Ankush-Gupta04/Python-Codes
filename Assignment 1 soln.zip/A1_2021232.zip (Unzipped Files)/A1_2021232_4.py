def fn_1(b1,b2,b3):                    # created a function for hardcoded bool function 
    return b1  and (not b1)             # return value of bool fn for a particular set
def fn_2(b1,b2,b3):                                                 # created a function for hardcoded bool function 
    return (b1 or b2) and (b2 or (not b3))                          # return value of bool fn for a particular set
b1 = [True , False]    # bi(where i = 1,2,3) is bool so only 2 posibility either true or false 
b2 = [True , False]
b3 = [True , False]
true_fn1 = []           # create empty lists for different scenerios
false_fn1 = []
true_fn2 = []
false_fn2 = []
for i in b1:                                 # loop for 2 values of b1
    for j in  b2:                             # loop for 2 values of b2
        for k in b3:                            # loop for 2 values of b3
            l_1 = [i,j,k]                         # there would be 8 cases and total 8 loop as 2**3 = 8
            if fn_1(i,j,k):                         # check for each case then append it to its characteristic list
                true_fn1.append(l_1)
            else:
                false_fn1.append(l_1)
            if fn_2(i,j,k):
                true_fn2.append(l_1)
            else:
                false_fn2.append(l_1)
if len(true_fn1) == 0:                              # if fn1 is always false then true wali list would be empty 
    print ("Fn1 is unsatisfiable")
else:
    print(f"Fn1 is satisfiable for all set of values in list {true_fn1} in order[b1,b2,b3] ")
if len(true_fn2) == 0:                              # if fn2 is always false then true wali list would be empty
    print ("Fn2 is unsatisfiable")
else:
    print(f"Fn2 is satisfiable for all set of values in list {true_fn2} in order[b1,b2,b3] ")