def calculate_area(l_e,a,b,d):
    x = a
    l = [a]
    while x < b:         # creating list for integration
        x = x + d
        l.append(x)
    len_l = len(l)
    if l[len_l - 1] >= b:
        l.pop()
    l.append(b)
    f_x = []
    for i in l:
        f = []           # polynomial terms
        for k in l_e:    
            t = i**k
            f.append(t)
        f_sum = sum(f)     #value of polynomial
        f_x.append(f_sum)  # creating list of desired polynomial terms
    l_fx = len(f_x)
    f_av = []              # for average of boundries of a integration
    for i in range(0,len_l-1,1):
        t_1 = l[i]
        t_2 = l[i+1]
        t_av = (t_1+t_2)/2
        f_av1 = []
        for k in l_e:
            t_3 = t_av**k
            f_av1.append(t_3)
        sum_av1 = sum(f_av1)
        f_av.append(sum_av1)
    l_fav = len(f_av)
    # integral of f from a to a+d == d/6*[f(a) + f(a+d) + 4*f(((a+d)+a)/2))]
    final = []
    for i in range(0,l_fx):
        if i > (l_fx - 2) :
            break
        else:
            final_fx = f_x[i] + f_x[i+1] + 4*f_av[i]
        final.append(final_fx)
    ans = sum(final)
    ans = ((d/6)*ans)
    return ans
    
l_e = [float(power) for power in input("Give list of all exponents of variables seprated by space ").split()]
a = float(input("Give lower cap for integration: "))
b = float(input("Give upper cap for integration: "))
d = float(input("Give common difference for sum terms: "))
if a > b:
    print("invalid input")
else:
    soln = calculate_area(l_e,a,b,d)
    print (soln)
'''
a = float(input())
b = float(input())
d = float(input())
l_e = [float(power) for power in input("Give list of all exponents of variables seprated by space ").split()]
x = a
l = [a]
while x < b:
    x = x + d
    l.append(x)
len_l = len(l)
if l[len_l - 1] >= b:
    l.pop()
l.append(b)
print(l)
f_x = []
for i in l:
    f = []
    for k in l_e:
        t = i**k
        f.append(t)
    f_sum = sum(f)
    f_x.append(f_sum)
print(f_x)
l_fx = len(f_x)
f_av = []
for i in range(0,len_l-1,1):
    t_1 = l[i]
    t_2 = l[i+1]
    t_av = (t_1+t_2)/2
    f_av1 = []
    for k in l_e:
        t_3 = t_av**k
        f_av1.append(t_3)
    sum_av1 = sum(f_av1)
    f_av.append(sum_av1)
print(f_av)
l_fav = len(f_av)
# integral of f from a to a+d == d/6*[f(a) + f(a+d) + 4*f(((a+d)+a)/2))]
final = []
for i in range(0,l_fx):
    if i > (l_fx - 2) :
        break
    else:
        final_fx = f_x[i] + f_x[i+1] + 4*f_av[i]
    final.append(final_fx)
print (final)
ans = sum(final)
print((d/6)*ans)
'''