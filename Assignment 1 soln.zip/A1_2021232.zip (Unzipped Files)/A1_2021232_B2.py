e = [float(en) for en in (input("Provide position vectors of light source in sequence ex,ey,ez seprated by a ',': ")).split(",")]
d = [float(dn) for dn in (input("Provide direction vectors of light ray in sequence dx,dy,dz seprated by a ',': ")).split(",")]
o = [float(on) for on in (input("Provide position vectors of origin of sphere in sequence ox,oy,oz seprated by a ',': ")).split(",")]
r = float(input("Give radius of the sphere: "))
inside = []
outside = []
on = []
#taking t as positive for one scenerio.
t = 0
print ("Point 1")
while t <= 1000:
    x = e[0] + t*d[0]
    y = e[1] + t*d[1]
    z = e[2] + t*d[2]
    dx = (x-o[0])**2
    dy = (y-o[1])**2
    dz = (z-o[2])**2
    if (dx + dy + dz) == (r**2):
        on.append(t)
        break
    elif (dx + dy + dz) < (r**2):
        inside.append(t)
    else:
        outside.append(t)
        break
    t = t +1
end = len(inside)
if len(outside) > 0 and len(on) != 0:
    print (f"the point of intersection is in decimal and it lies between {inside[end-1]} & {outside[0]}")
    # it cant calculate as i cant think of code for decimal with spot on precission as decimal can varry upto any decimal places.
else:
    point = on[0]
    point_x1 = e[0] + point*d[0]
    point_x2 = e[1] + point*d[1]
    point_x3 = e[2] + point*d[2]
print(f"point of intersection is {point_x1},{point_x2},{point_x3}")
print ("Point 2")
inside_neg = []
outside_neg = []
on_neg = []
#taking t as neg for one scenerio.
t = 0
while t >= -1000:
    x = e[0] + t*d[0]
    y = e[1] + t*d[1]
    z = e[2] + t*d[2]
    dx = (x-o[0])**2
    dy = (y-o[1])**2
    dz = (z-o[2])**2
    if (dx + dy + dz) == (r**2):
        on_neg.append(t)
        break
    elif (dx + dy + dz) < (r**2):
        inside_neg.append(t)
    else:
        outside_neg.append(t)
        break
    t = t +1
end_neg = len(inside_neg)
if len(outside_neg) > 0 and len(on_neg) != 0:
    print (f"the point of intersection is in decimal and it lies between {inside_neg[end-1]} & {outside_neg[0]}")
    # it cant calculate as i cant think of code for decimal with spot on precission as decimal can varry upto any decimal places.
else:
    point = on_neg[0]
    point_x1neg = e[0] + point*d[0]
    point_x2neg = e[1] + point*d[1]
    point_x3neg = e[2] + point*d[2]
print(f"point of intersection is {point_x1neg},{point_x2neg},{point_x3neg}")
print("Line intersect sphere at 2 points only so there are no further point")