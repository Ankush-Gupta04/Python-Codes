def getReverse(x):                                                   # creating functions for each case for simplicity
    print("Your input number will be get reversed.")
    x = str(x)
    l = list(x)
    l.reverse()
    y = ""
    for i in l:
        y = y+i
    y = int(y)
    print(y)
    return
def checkPalindrome(x):
    print("Your input number will be checked for Palindrome.")
    x = str(x)
    l = list(x)
    # let input is 122
    # l = [1,2,2]
    length = len(l) # length = 3
    # 0 = 1 , 1 = 2 , 2 = 2 
    if length % 2 == 0:
        check_length = int(length/2)  # 2
        l_1 = l[0:check_length]
        l_2 = l[check_length:]
        l_2.reverse()
    else:
        check_length = int(length/2) # 1
        l_1 = l[0:check_length]
        l_2 = l[check_length+1 : ]
        l_2.reverse()
    if l_1 == l_2:
        print (True)
    else:
        print (False)
    return
def checkNarcissistic(x):
    print("Your input number will be checked for Narcissistic .")
    x = str(x)
    l = list(x)
    length = len(l)
    for i in range(0,length):
        l[i] = (int(l[i]))**(length)
    sum_l = sum(l)
    x = int(x)
    if x == sum_l:
        print(True)
    else:
        print(False)
    return
def findDigitSum(x):
    print("The digits of Your input number will be summed.")
    x = str(x)
    l = list(x)
    length = len(l)
    for i in range(0,length):
        l[i] = (int(l[i]))
    sum_l = sum(l)
    sum_f = [sum_l]
    while sum_l > 9:
        sum_l= str(sum_l)
        l_1 = list(sum_l)
        length = len(l_1)
        for i in range(0,length):
            l_1[i] = (int(l_1[i]))
        sum_l = sum(l_1)
        sum_f.append(sum_l)
    sum_final = sum(sum_f)
    print(f"The list of Sum of digits till single digit is {sum_f} and their sum is {sum_final}")
    return
def findSquareDigitSum(x):
    print("The digits of Your input number will be squared then will be summed up.")
    x = str(x)
    l = list(x)
    length = len(l)
    for i in range(0,length):
        l[i] = (int(l[i]))**2
    sum_l = sum(l)
    print (f"The sum of squares of digits ({l}) is {sum_l}")
    return
while 5 != 0:    # for infinite loop
    print ("--------------------------------------------------------------------------------------------------------------------------------")
    print("")
    print("Hello User,Welcome to the Application. Please select one of the operations.")
    print("1: Find reverse of a number")
    print("2: Check whether a number is a palindrome or not.")
    print("3: Check whether a number is a Narcissistic number or not.")
    print("4: Find the sum of digits of a number.")
    print("5: Find the sum of squares of digits of a number.")
    print("6: Select 6 to exit the application.")
    print("")
    print("--------------------------------------------------------------------------------------------------------------------------------")
    code = int(input("Enter the code of your choice that you want the application to perform: "))
    if code<= 0 or code>6 :
        print("Warning: You entered the wrong Code")
    elif code == 6:
        print("You chose to exist.")
        break                   #breaking infinite loop
    else: 
        print(f"You chose code number {code}.")
        n = int(input("Enter a non negeative integer: "))         # due to qs condition and taking integer as required process carries on only integer.
        if n < 0:
            print ("You entered a negeative number.")
            print("Retry")
        else:
            print(f"You have given {n} as test case.")
            if code == 1:
                getReverse(n)
            elif code == 2:
                checkPalindrome(n)
            elif code == 3:
                checkNarcissistic(n)
            elif code == 4:
                findDigitSum(n)
            elif code == 5:
                findSquareDigitSum(n)            