cost = float(input("Give initial cost of Car: "))
rate = float(input("Give per year rate of depression: "))
rate_m = 1 # increase 50% after 5 every year
value_km = 50 # 10% increase every year
km_year = 6000
d_year = (rate)*(cost)/100
cost_f = cost # introduced due to loop 
for t in range(1,17):
    if t > 15:
        print("You have used car succesfully for 15 years. Congrats, Now sell it as you cant use it now.")
        break
    else:
        if t <= 5:
            cost_m = cost*1/100*t
        else:
            cost_m = (cost*5/100)*((1.5)**(t-5))
        cost_f = cost_f - d_year - cost_m
        value_yr = (value_km)*((1.1)**t)
        value_f = value_yr * 6000
        if value_f > cost_f:
            print(f"Sell car after {t} year(s)")
            break