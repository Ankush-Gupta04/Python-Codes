import math
def scaling(sx,sy,sz,x,y,z):
    x_s = []
    for i in x:
        n = sx*i
        x_s.append(n)
    y_s = []
    for i in y:
        n = sy*i
        y_s.append(n)
    z_s = []
    for i in z:
        n = sz*i
        z_s.append(n)
    return [x_s , y_s , z_s]
def translating(tx,ty,tz,x,y,z):
    x_t = []
    y_t = []
    z_t = []
    for i in x:
        n = 1*i + tx
        x_t.append(n)
    for i in y:
        n = 1*i + ty
        y_t.append(n)
    for i in z:
        n = 1*i + tz
        z_t.append(n)
    return [x_t , y_t , z_t]
def rotation(axis,angle,x,y,z,len_l):
    x_r = []
    y_r = []
    z_r = []
    sin = math.sin(math.radians(angle))
    cos = math.cos(math.radians(angle))
    if axis == 'x':
        for i in range(0,len_l):
            xx = 1*x[i]
            x_r.append(xx)
            yy = cos*y[i] - sin*z[i]
            y_r.append(yy)
            zz = sin*y[i] + cos*z[i]
            z_r.append(zz)
    elif axis == 'y':
        for i in range(0,len_l):
            xx = cos*x[i] + sin*z[i]
            x_r.append(xx)
            yy = 1*y[i]
            y_r.append(yy)
            zz = -sin*x[i] + cos*z[i]
            z_r.append(zz)
    else:           # axis = 'z' 
        for i in range(0,len_l):
            xx = cos*x[i] - sin*y[i]
            x_r.append(xx)
            yy = cos*y[i] + sin*x[i]
            y_r.append(yy)
            zz = 1*z[i]
            z_r.append(zz)
    return [x_r,y_r,z_r]
def matmul(a,b):
    m = len(a)
    n = len(a[0])
    p = len(b[0])
    ans = []
    for i in range(m):
        ank = []
        for j in range(p):
            s = 0
            for k in range (n):
                s = s + (a[i][k] * b[k][j])
            ank.append(s)
        ans.append(ank)
    return (ans)