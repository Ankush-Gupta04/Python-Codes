from A3_2021232_1_fn import *
def test_matmul(a,b,true_c):
    try:
        c = matmul(a,b)
        assert true_c == c
        return True
    except:
        return False

def test_scale(x,y,z,sx,sy,sz,true_sx,true_sy,true_sz):
    try:
        c = scaling(sx,sy,sz,x,y,z)
        c_sx = c[0]
        c_sy = c[1]
        c_sz = c[2]
        assert c_sx == true_sx and c_sy == true_sy and c_sz == true_sz 
        return True
    except:
        return False

def test_translate(x,y,z,sx,sy,sz,true_sx,true_sy,true_sz):
    try:
        c = translating(sx,sy,sz,x,y,z)
        c_sx = c[0]
        c_sy = c[1]
        c_sz = c[2]
        assert c_sx == true_sx and c_sy == true_sy and c_sz == true_sz 
        return True
    except:
        return False

def test_rotate(x,y,z,axis,phi,true_sx,true_sy,true_sz):
    try:
        len_l = len(x)
        c = rotation(axis,phi,x,y,z,len_l)
        c_sx = c[0]
        c_sy = c[1]
        c_sz = c[2]
        assert c_sx == true_sx and c_sy == true_sy and c_sz == true_sz 
        return True
    except:
        return False

while 4!=0:
    print("--------------Menu---------------------")
    print("1: Matrix multiplication of 2 matrixes")
    print("2: Scale of a matrix")
    print("3: translate of a matrix")
    print("4: Rotate of a matrix")
    print("5: Exit")
    c = int(input())
    if c == 1:
        p = int(input("number of cases to test"))
        for i in range(p):
            aa = [int(x) for x in input("Dimension").split()]
            a,b,true_c = [],[],[]
            for i in range(aa[0]):
                pp = [float(x) for x in input().split()]
                a.append(pp)
            for i in range(aa[1]):
                pp = [float(x) for x in input().split()]
                b.append(pp)
            for i in range(aa[0]):
                pp = [float(x) for x in input().split()]
                true_c.append(pp)
            print (test_matmul(a,b,true_c))
    elif c == 2:
        p = int(input("number of cases to test"))
        for i in range(p):
            true_c = []
            xx = [float(x) for x in input().split()]
            yy = [float(x) for x in input().split()]
            zz = [float(x) for x in input().split()]
            true_xx = [float(x) for x in input().split()]
            true_yy = [float(x) for x in input().split()]
            true_zz = [float(x) for x in input().split()]
            sx = float(input())
            sy = float(input())
            sz = float(input())           
            print (test_scale(xx,yy,zz,sx,sy,sz,true_xx,true_yy,true_zz))
    elif c == 3:
        p = int(input("number of cases to test"))
        for i in range(p):
            true_c = []
            xx = [float(x) for x in input().split()]
            yy = [float(x) for x in input().split()]
            zz = [float(x) for x in input().split()]
            true_xx = [float(x) for x in input().split()]
            true_yy = [float(x) for x in input().split()]
            true_zz = [float(x) for x in input().split()]
            sx = float(input())
            sy = float(input())
            sz = float(input())           
            print (test_translate(xx,yy,zz,sx,sy,sz,true_xx,true_yy,true_zz))
    elif c == 4:
        p = int(input("number of cases to test"))
        for i in range(p):
            true_c = []
            xx = [float(x) for x in input().split()]
            yy = [float(x) for x in input().split()]
            zz = [float(x) for x in input().split()]
            true_xx = [float(x) for x in input().split()]
            true_yy = [float(x) for x in input().split()]
            true_zz = [float(x) for x in input().split()]
            phi = float(input())
            axis = (input())          
            print (test_rotate(xx,yy,zz,axis,phi,true_xx,true_yy,true_zz))
    elif c == 5:
        break
    else:
        print("Wrong Code") 