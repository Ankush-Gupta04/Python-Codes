class Student:
    def __init__ (self,n,c,b):
        self.name = n
        self.cgpa = c
        self.branch = b
        self.status = "Unplaced"
    def isplaced(self):
        if self.branch in ["CSE" , "CSAM" , "ECE"]:
            return True
        else:
            return False
    def isEligible(self,r):
        tt = False
        if self.cgpa >= r.cgpa:
            if self.branch in r.branchlst:
                if self.status == "Unplaced":
                   tt = True
        if tt:
            print (f"{self.name} is elligible for applying in {r.name}")
        else:
            print (f"{self.name} is not elligible for applying in {r.name}")
        return tt
    def apply (self,r):
        if self.cgpa > r.cgpa and self.status == "Unplaced" and self.branch in r.branchlst:
            r.lst.append(self)
    def getPlaced(self):
        self.status = "Placed"

class Company:
    def __init__ (self,n,c,b,p):
        self.name = n
        self.cgpa = c
        self.branchlst = b
        self.no = p
        self.lst = []
        self.hired = []
        self.appl = True
    
    def  closeApplication(self):
        self.appl = False
    def hireStudents(self):
        cc = []
        for i in self.lst:
            cc.append(i.cgpa)
        rr = []
        #print (self.hired)
        for i in (self.lst):
            rr.append(i.cgpa)
        #print (rr)
        for i in rr:
            c = max(rr)
            #print (c)
            p = rr.index(c)
            #print (self.hired[p])
            #print(self.hired[p].name)
            self.hired.append(self.lst[p])
            rr[p] = -1
        self.hired = self.hired[0:self.no]
        ans = []
        for i in self.hired:
            i.getPlaced()
            ans.append(i.name)
        print (f"Company {self.name} has hired {len(ans)} i.e. {ans}")
        self.closeApplication()

s = int(input("number of student"))
if s >= 5:
    s_l = []
    for i in range(s):
        try:
            print (f"Student {i+1}")
            print ("Information includes Name, Cgpa, Branch")
            ku = [x for x in input("Give information of student (space-seperated)").split()]
            assert float(ku[1]) >=0 and float(ku[1]) <=10, "Cgpa is not valid!!"
            be = Student(ku[0] , float(ku[1]) , ku[2])
            s_l.append(be)
        except: 
            print("Cgpa is not valid!!  ,  So this case will not be considered.")

else:
    print("not required amount of students")
rb = int(input("number of company"))
if rb >=2:
    for i in range(rb):
        try:
            print (f"Company {i+1}")
            print ("Information includes Name, Required-Cgpa , maximum no of seats offered")
            ku = [x for x in input("Give information of company (space-seperated)").split()]
            assert float(ku[1]) >=0 and float(ku[1]) <=10, "Cgpa is not valid!!"
            be = [i for i in input("Give the list of desired branches space-seperated").split()]
            Comp = Company(ku[0] , float(ku[1]) , be , int(ku[2]))
            for j in s_l:
                j.isEligible(Comp)
                j.apply(Comp)
            Comp.hireStudents()
        except AssertionError: 
            print("Cgpa is not valid!!  ,  So this case will not be considered.")