class LaundryService :
    def __init__(self,n,c,e,t,b,s):
        self.name = n
        self.contact = c
        self.email = e
        self.ctype = t
        self.branded = b
        self.season = s
        global i
        self.id = i
        
    def customerDetails(self):
        print (f"Coustomer Id  ::  {self.id}")
        print(f"Name ::  {self.name}")
        print(f"Contact ::  {self.contact}")
        print(f"Email  ::  {self.email}")
        print(f"Cloth type  :: {self.ctype}")
        print(f"Isbranded  ::  {self.branded}")
    
    def calculateCharge(self):
        if self.ctype == "Cotton":
            price = 50
        elif self.ctype == "Silk":
            price = 30
        elif self.ctype == "Woolen":
            price = 90
        elif self.ctype == "Polyester":
            price = 20
        if self.branded:
            price = price * (1.5)
        if self.season == "Winter":
            price = price/2
        else:
            price = price*2
        return price   

    def finalDetails(self):
        self.customerDetails()
        c = self.calculateCharge()
        print (f"Total charges of washing  :: Rs.{c}")
        if c > 200:
            print ('To be returned in 4 days')
        else:
            print ('To be returned in 7 days')
nt = int(input("Number of clients of Washing Service "))       
for i in range(1,nt+1,1):
    n = input("Name of Customer: ")
    c = int(input("Contact No "))
    e = input("Email: ")
    t = input ("Type of cloth: ")
    b = int(input("Give 0 if not branded else 1:"))
    s = input("Season: ")
    client = LaundryService(n,c,e,t,b,s)
    client.finalDetails()