class Person:
    def __init__(self,f,l,a):
        self.first = f
        self.last = l
        self.age = a
    def object_info (self):
        return [self.first , self.last , self.age]

print ("Welcome, Sir!!")
i = 1
while  i != 0:
    n = int(input("No of persons enrolled"))
    l = []
    for i in range(n):
        print (f"Person-{i+1}")
        p = [x for x in input("Give all informations of person (space-seperated): ").split()]
        if p[2].isdecimal():
            c = Person(p[0],p[1],int(p[2]))
            pp = c.object_info()
            l.append(pp)
        else:
            print ("Wrong input, will not be ContentDispositionHeader")
    k = int(input("No of queries: "))
    for i in range(k):
        print (f"Query{i+1}")
        print ("---Menu---")
        print ("1: First Name")
        print ("2: Last Name")
        print ("3: Age")
        ank = int(input("Code: "))
        if ank < 4 and ank >0:
            cc = []
            for i in l:
                cc.append(i[ank-1])
            rr = []
            rr.extend(cc)
            rr.sort()
            ans = []
            for i in rr:
                p = l[cc.index(i)]
                ans.append(p)
            for i in ans :
                s = i[0] + " " + i[1] + " " + str(i[2])   
                print (s)            
        else:
            print ("Wrong input for code")
    print("Thanks for using")
    i = int(input("Enter 0 if you don't want to continue else 1: "))
    if i == 0:
        print ("Exit")