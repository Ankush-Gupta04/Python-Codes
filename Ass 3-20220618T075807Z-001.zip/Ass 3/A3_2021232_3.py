from datetime import datetime
print ("Welcome to the Bank of IIIT-D,the service that you can trust")
class BankAccount:
    def __init__(self,n,p,a):
        self.name = n
        self.password = p
        self.amount = a
        with open(f"{n}.txt" , "w") as f:
            f.write(f"{datetime.now()} :: Current Balance:{a} , amount added:{a}" + "\n")

    def authenticate(self):
        ch = input("Secret Password: ") 
        if ch == self.password:
            return True
        else:
            return False
    def deposit(self,am):
        try:
            n = 0
            tt = False
            while n <3:
                if self.authenticate():
                    tt = True
                    break
                else: 
                    print (f"failed attempt: {n+1}")
                    n = n + 1
            assert tt , "Too many Wrong attempts!!"
            self.amount += am
            with open(f"{self.name}.txt" , "a") as f:
                f.write(f"{datetime.now()} :: Current Balance:{self.amount} , Amount added:{am}" + "\n")
        except:
            print ("Too many wrong attempts !!")
    def withdraw(self,am):
        try:
            n = 0
            tt = False
            while n <3:
                if self.authenticate():
                    tt = True
                    break
                else: 
                    print (f"failed attempt: {n+1}")
                    n = n + 1
            assert tt , "Too many Wrong attempts!!"
            if self.amount >= am:
                self.amount -= am
                with open(f"{self.name}.txt" , "a") as f:
                    f.write(f"{datetime.now()} :: Current Balance:{self.amount} , Amount debited:{am}" + "\n")
            else:
                raise Exception ("Balance is low")
        except AssertionError:
            print ("Too many wrong attempts !!")
        except:
            print ("Low balance!! Cannot be debited at this time!")
    def bankstatement(self):
        try:
            n = 0
            tt = False
            while n <3:
                if self.authenticate():
                    tt = True
                    break
                else: 
                    print (f"failed attempt: {n+1}")
                    n = n + 1
            assert tt , "Too many Wrong attempts!!"
            if tt:
                with open(f"{self.name}.txt" , "r") as f:
                    c = f.read()
                print (f"Hey, {self.name}, Your transaction History is:")
                l = [x for x in c.split("\n")]
                for i in l:
                    print (i)
        except AssertionError:
            print ("Too many wrong attempts !!")

n = input("Name: ")
p = input("Password: ")
a = float(input("Initial Amount: "))
cl = BankAccount(n,p,a)      
while 4!= 0:
    print ("------Menu------")
    print ("1: Deposit")
    print ("2: Withdraw")
    print ("3 : Bank Statement")
    p = int(input("Code no:"))
    if p == 1:
        am = float(input("Amount to be deposited: "))
        cl.deposit(am)
    elif p == 2:
        am = float(input("Amount to be withdrawn: "))
        cl.withdraw(am)
    elif p == 3:
        cl.bankstatement()
    else:
        print ("Wrong Code")
    i = int(input("Give 0 if you don't want to continue else 1"))
    if i:
        if cl.authenticate():
            pass
        else:
            break
    else:
        break